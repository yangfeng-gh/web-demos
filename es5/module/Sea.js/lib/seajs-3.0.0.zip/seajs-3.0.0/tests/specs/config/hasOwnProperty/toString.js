define({ name: 'toString' });
