define(function(require, exports) {
  exports.name = 'c'
});
