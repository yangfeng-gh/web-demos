define(function(require, exports) {

  exports.name = 'monkeys'
  require('./sub')

});

