define('./map/debug/b-debug', [], { name: 'b' })
define('./map/debug/a-debug', [], { name: 'a' })